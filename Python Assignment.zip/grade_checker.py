# Function to collect score
def get_score():
    score = int(input("Enter your score: "))
    return score


# Function to calculate grade
def calculate_grade(score):

    if score >= 70:
        return "A"

    elif score >= 60:
        return "B"

    elif score >= 50:
        return "C"

    elif score >= 45:
        return "D"

    elif score >= 40:
        return "E"

    else:
        return "F"


# Function to display result
def display_result(score, grade):

    print("Score:", score)
    print("Grade:", grade)


# Main program
student_score = get_score()

student_grade = calculate_grade(student_score)

display_result(student_score, student_grade)