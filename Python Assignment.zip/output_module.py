def display_result(score, grade):

    print("Score:", score)

    print("Grade:", grade)