from input_module import get_score
from logic_module import calculate_grade
from output_module import display_result


student_score = get_score()

student_grade = calculate_grade(student_score)

display_result(student_score, student_grade)